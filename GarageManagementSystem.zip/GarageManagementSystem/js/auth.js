/* =====================================================================
   FILE: auth.js
   PURPOSE: Handles user authentication - login state management,
            checking who is logged in, and logout.
            This file is loaded on EVERY page.

   CONCEPTS USED FROM CLASS:
   - Objects (Lab 4 - object.js)
   - Functions & Arrow Functions (Lab 3 - function.js)
   - DOM Manipulation (JS - DOM - firstdom.js)
   - Events (Events in JS - event.js)
   - Conditional Statements (Lecture 3 - condt_stat.js)
   ===================================================================== */


/* -----------------------------------------------------------------------
   CURRENT SESSION MANAGEMENT
   We store the currently logged-in user in sessionStorage.
   sessionStorage is like localStorage but clears when browser tab closes.
   ----------------------------------------------------------------------- */

// Get the currently logged-in user object (returns null if no one is logged in)
const getCurrentUser = () => {
    const userStr = sessionStorage.getItem("gms_current_user");

    // Conditional statement from Lecture 3
    if (userStr) {
        return JSON.parse(userStr);  // Parse JSON string back to object
    }
    return null;  // No user is logged in
};

// Check if any user is logged in
const isLoggedIn = () => {
    return getCurrentUser() !== null;
};

// Check if the logged in user is an admin
const isAdmin = () => {
    const user = getCurrentUser();
    // Conditional (if-else) from Lecture 3
    if (user && user.role === "admin") {
        return true;
    }
    return false;
};

// Save user to session (called on successful login)
const setCurrentUser = (userObj) => {
    sessionStorage.setItem("gms_current_user", JSON.stringify(userObj));
};

// Clear session (called on logout)
const clearCurrentUser = () => {
    sessionStorage.removeItem("gms_current_user");
};


/* -----------------------------------------------------------------------
   LOGOUT FUNCTION
   Clears the session and redirects to homepage.
   ----------------------------------------------------------------------- */
function logout() {
    clearCurrentUser();             // Remove session data
    window.location.href = "index.html"; // Redirect to home
}


/* -----------------------------------------------------------------------
   NAVBAR STATE UPDATE
   This function updates the navbar to show the correct buttons
   depending on whether a user is logged in or not.

   DOM Manipulation concept from JS-DOM lab (firstdom.js)
   getElementById is discussed in DOM lab
   ----------------------------------------------------------------------- */
function updateNavbar() {

    const user = getCurrentUser();

    // ---- Update Navbar on INDEX page ----
    // getElementById() - DOM concept from class
    const navLoginBtn  = document.getElementById("navLoginBtn");
    const navUserName  = document.getElementById("navUserName");
    const navLogoutBtn = document.getElementById("navLogoutBtn");
    const navAdminBtn  = document.getElementById("navAdminBtn");
    const loggedUserNameSpan = document.getElementById("loggedUserName");
    const logoutLink = document.getElementById("logoutLink");

    // Only run if these elements exist on the page
    if (navLoginBtn) {
        if (user) {
            // User is logged in: hide login link, show name and logout
            navLoginBtn.classList.add("d-none");
            navUserName.classList.remove("d-none");
            navLogoutBtn.classList.remove("d-none");

            // Display user's name in navbar
            if (loggedUserNameSpan) {
                loggedUserNameSpan.textContent = "👤 " + user.name;
            }

            // Show Admin button only if user is admin
            if (navAdminBtn && user.role === "admin") {
                navAdminBtn.classList.remove("d-none");
            }

            // Attach logout event using addEventListener (from Events lab)
            if (logoutLink) {
                logoutLink.addEventListener("click", function(event) {
                    event.preventDefault(); // Prevent default href="#" jump
                    logout();               // Call our logout function
                });
            }

        } else {
            // No user logged in: show login, hide user-related buttons
            navLoginBtn.classList.remove("d-none");
            navUserName.classList.add("d-none");
            navLogoutBtn.classList.add("d-none");
            if (navAdminBtn) navAdminBtn.classList.add("d-none");
        }
    }

    // ---- Update Navbar on MARKETPLACE page ----
    const mktLoginBtn  = document.getElementById("mktLoginBtn");
    const mktUserBtn   = document.getElementById("mktUserBtn");
    const mktUserName  = document.getElementById("mktUserName");
    const mktLogoutBtn = document.getElementById("mktLogoutBtn");
    const mktLogout    = document.getElementById("mktLogout");

    if (mktLoginBtn) {
        if (user) {
            mktLoginBtn.classList.add("d-none");
            mktUserBtn.classList.remove("d-none");
            mktLogoutBtn.classList.remove("d-none");
            if (mktUserName) mktUserName.textContent = "👤 " + user.name;
            if (mktLogout) {
                mktLogout.addEventListener("click", function(e) {
                    e.preventDefault();
                    logout();
                });
            }
        } else {
            mktLoginBtn.classList.remove("d-none");
            mktUserBtn.classList.add("d-none");
            mktLogoutBtn.classList.add("d-none");
        }
    }

    // ---- Update Navbar on SERVICE page ----
    const svcLoginBtn  = document.getElementById("svcLoginBtn");
    const svcUserBtn   = document.getElementById("svcUserBtn");
    const svcUserName  = document.getElementById("svcUserName");
    const svcLogoutBtn = document.getElementById("svcLogoutBtn");
    const svcLogout    = document.getElementById("svcLogout");

    if (svcLoginBtn) {
        if (user) {
            svcLoginBtn.classList.add("d-none");
            svcUserBtn.classList.remove("d-none");
            svcLogoutBtn.classList.remove("d-none");
            if (svcUserName) svcUserName.textContent = "👤 " + user.name;
            if (svcLogout) {
                svcLogout.addEventListener("click", function(e) {
                    e.preventDefault();
                    logout();
                });
            }
        } else {
            svcLoginBtn.classList.remove("d-none");
            svcUserBtn.classList.add("d-none");
            svcLogoutBtn.classList.add("d-none");
        }
    }

} // End of updateNavbar()


/* -----------------------------------------------------------------------
   AUTO-RUN WHEN PAGE LOADS
   window.onload event - Event concept from Events in JS lab (event.js)
   This ensures navbar is always updated correctly on every page load.
   ----------------------------------------------------------------------- */
window.addEventListener("load", function() {
    updateNavbar();  // Update navbar state on every page load
    console.log("✅ auth.js loaded. Current user:", getCurrentUser());
});
