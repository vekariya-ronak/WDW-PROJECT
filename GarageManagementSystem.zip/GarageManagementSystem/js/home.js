/* =====================================================================
   FILE: home.js
   PURPOSE: JavaScript for the Home Page (index.html)
            - Shows stats (total deals, total services)
            - Uses DOM manipulation to insert content dynamically

   CONCEPTS USED FROM CLASS:
   - DOM Manipulation (JS-DOM - firstdom.js)
   - Objects (Lab 4 - object.js)
   - Arrow Functions (Lab 3 - function.js)
   - Events (Events in JS - event.js)
   - for...of loop (Lab 2 - loop.js)
   ===================================================================== */


/* -----------------------------------------------------------------------
   FUNCTION: loadStats
   PURPOSE : Reads stats from localStorage and displays them on the homepage.
   USES     : DOM createElement(), textContent, appendChild() - from firstdom.js
   ----------------------------------------------------------------------- */
function loadStats() {

    // Get the stats container div from HTML
    const statsSection = document.getElementById("statsSection");

    // If this element does not exist, stop (maybe we're on a different page)
    if (!statsSection) return;

    // Get the stats object from localStorage using our data.js function
    const stats = getStats();

    // Also count total available (unsold) cars from marketplace
    const availableCars = getAvailableCars();   // Array from data.js
    const totalCars     = availableCars.length;  // Array .length property (Lab 4)

    // Count total registered users (excluding admin)
    const allUsers   = getAllUsers();
    let   totalUsers = 0;

    // for...of loop concept from Lab 2 (loop.js)
    for (let user of allUsers) {
        if (user.role !== "admin") {
            totalUsers++;  // Increment counter (unary operator from Lecture 2)
        }
    }

    // ---- Array of stat card data (Array of Objects - Lab 4) ----
    const statItems = [
        { label: "Successful Deals",     value: stats.totalDeals,    icon: "🤝", color: "text-warning" },
        { label: "Services Completed",   value: stats.totalServices,  icon: "✅", color: "text-success" },
        { label: "Cars Available",       value: totalCars,            icon: "🚗", color: "text-info"    },
        { label: "Registered Users",     value: totalUsers,           icon: "👥", color: "text-light"   }
    ];

    // Clear existing content before re-rendering
    statsSection.innerHTML = "";

    // ---- Create stat cards dynamically using DOM (from firstdom.js) ----
    // for...of loop through statItems array
    for (let item of statItems) {

        // createElement() - DOM concept from class (firstdom.js line 70)
        const col  = document.createElement("div");
        col.className = "col-6 col-md-3";

        // Use innerHTML to set inner content of each card
        col.innerHTML = `
            <div class="stat-card p-3 text-center">
                <div style="font-size:2rem;">${item.icon}</div>
                <div class="display-5 fw-bold ${item.color}" id="stat_count_${item.label.replace(/\s/g,'')}">${item.value}</div>
                <small class="text-light">${item.label}</small>
            </div>
        `;

        // appendChild() - DOM concept (firstdom.js line 73)
        statsSection.appendChild(col);

        // Animate the count from 0 to target value using a counter animation
        animateCounter(
            document.getElementById("stat_count_" + item.label.replace(/\s/g, "")),
            item.value
        );
    }

} // End of loadStats()


/* -----------------------------------------------------------------------
   FUNCTION: animateCounter
   PURPOSE : Animates a number from 0 to target (visual effect)
   PARAMS  : element - the DOM element to update
             target  - the final number to count up to
   USES    : Closure concept (Lab 5 - closure.js) + setInterval
   ----------------------------------------------------------------------- */
function animateCounter(element, target) {

    // If element doesn't exist, stop
    if (!element) return;

    let current = 0;           // Start from 0
    const step  = Math.ceil(target / 30);  // Divide into 30 steps

    // setInterval runs a function repeatedly at a given interval (milliseconds)
    // This creates an animation effect where number counts up
    const interval = setInterval(function() {

        current += step;  // Increment current by step

        // Conditional to stop animation when target is reached
        if (current >= target) {
            current = target;         // Set exact target value
            clearInterval(interval);  // Stop the interval (stop counting)
        }

        // textContent - DOM concept (firstdom.js line 77)
        element.textContent = current;

    }, 50);  // Run every 50 milliseconds

} // End of animateCounter()


/* -----------------------------------------------------------------------
   EVENT: DOMContentLoaded
   Run loadStats() when the DOM is fully loaded.
   DOMContentLoaded concept from Events in JS lab (event.js line 110)
   ----------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function() {
    loadStats();  // Load and display homepage stats
    console.log("✅ home.js loaded. Stats displayed.");
});
