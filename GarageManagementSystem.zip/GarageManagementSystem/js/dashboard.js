/* =====================================================================
   FILE: dashboard.js
   PURPOSE: User Dashboard logic (dashboard.html)
            - Show user's car listings
            - Add new car for sale
            - Show/hide listed products
            - View service request status
            - Image preview for car photo

   CONCEPTS USED FROM CLASS:
   - Objects (Lab 4 - object.js)
   - Arrays + Array methods push(), filter() (Lab 4 - array.js)
   - Functions & Arrow Functions (Lab 3 - function.js)
   - DOM createElement(), appendChild(), textContent (firstdom.js)
   - Events - addEventListener, onchange (Events lab - event.js)
   - Conditional statements (Lecture 3 - condt_stat.js)
   - Destructuring (Lab 5 - destructuring.js)
   - for...of loop (Lab 2 - loop.js)
   ===================================================================== */


/* -----------------------------------------------------------------------
   GLOBAL VARIABLE: tracks if user's product list is currently visible
   Closure concept: variable shared across functions in this file (Lab 5)
   ----------------------------------------------------------------------- */
let productsVisible = false;


/* -----------------------------------------------------------------------
   FUNCTION: showDashTab
   PURPOSE : Toggle between dashboard tabs (My Listings, Add Car, Services)
   PARAM   : tabName - "myListings", "addCar", or "myServices"
   USES    : DOM classList (firstdom.js concepts)
   ----------------------------------------------------------------------- */
function showDashTab(tabName) {

    // Array of all tab content section ids
    const allTabs = ["myListings", "addCar", "myServices"];

    // for...of loop (Lab 2 - loop.js) to hide all sections first
    for (let tab of allTabs) {
        const el = document.getElementById(tab);
        if (el) el.classList.add("d-none");  // Hide each section
    }

    // Now show only the selected tab
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) selectedTab.classList.remove("d-none");

    // If switching to myListings or myServices, load their content
    if (tabName === "myListings") {
        loadMyListings();
    } else if (tabName === "myServices") {
        loadMyServices();
    }

} // End of showDashTab()


/* -----------------------------------------------------------------------
   FUNCTION: toggleMyProducts
   PURPOSE : Show/Hide the user's car listings when button is clicked
   USES    : Conditional, DOM visibility toggle
   ----------------------------------------------------------------------- */
function toggleMyProducts() {

    const container = document.getElementById("myCarListContainer");

    // Conditional toggle (Lecture 3 - condt_stat.js)
    if (productsVisible) {
        // Currently visible → hide
        container.innerHTML = "";    // Clear the container
        productsVisible = false;
    } else {
        // Currently hidden → show
        loadMyListings();            // Load and show listings
        productsVisible = true;
    }

} // End of toggleMyProducts()


/* -----------------------------------------------------------------------
   FUNCTION: loadMyListings
   PURPOSE : Loads and displays all cars listed by the current logged-in user
   USES    : Array.filter(), for...of loop, DOM createElement, appendChild
   ----------------------------------------------------------------------- */
function loadMyListings() {

    const user = getCurrentUser();  // auth.js function

    // If not logged in, redirect to login
    if (!user) {
        window.location.href = "login.html";
        return;
    }

    const container = document.getElementById("myCarListContainer");
    const noMsg     = document.getElementById("noListingsMsg");

    if (!container) return;

    // Get all cars, then filter to only THIS user's cars
    // Array.filter() concept from Lab 4 (array.js)
    const allCars  = getAllCars();
    const myCars   = allCars.filter(function(car) {
        return car.ownerId === user.id;
    });

    // Clear existing content before re-rendering
    container.innerHTML = "";

    // If no cars listed, show message
    if (myCars.length === 0) {
        if (noMsg) noMsg.classList.remove("d-none");
        return;
    }

    // Hide the "no listings" message
    if (noMsg) noMsg.classList.add("d-none");

    // for...of loop (Lab 2) to render each car as a card
    for (let car of myCars) {

        // Create a Bootstrap column div using createElement() (DOM lab)
        const col = document.createElement("div");
        col.className = "col-12 col-md-6 col-lg-4";

        // Determine badge color based on sold status
        // Conditional (Ternary operator) from Lecture 3
        const soldBadge = car.isSold
            ? `<span class="badge bg-secondary">Sold</span>`
            : `<span class="badge bg-success">Available</span>`;

        // Set card HTML with all car details
        // formatINR() from data.js to display price in Indian Rupee format
        col.innerHTML = `
            <div class="card h-100 shadow-sm car-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold">${car.brand} ${car.model}</span>
                    ${soldBadge}
                </div>
                <div class="card-body">
                    ${car.photo ? `<img src="${car.photo}" alt="Car Photo" class="img-fluid rounded mb-2" style="max-height:150px;width:100%;object-fit:cover;">` : ''}
                    <p class="mb-1"><strong>Owner:</strong> ${car.ownerName}</p>
                    <p class="mb-1"><strong>Year:</strong> ${car.year}</p>
                    <p class="mb-1"><strong>Condition:</strong> ${car.condition}</p>
                    <p class="mb-1"><strong>KM Driven:</strong> ${Number(car.km).toLocaleString("en-IN")} km</p>
                    <p class="mb-1"><strong>Contact:</strong> ${car.contact}</p>
                    <p class="mb-1"><strong>Address:</strong> ${car.address}</p>
                    <p class="text-success fw-bold fs-5">${formatINR(car.price)}</p>
                </div>
                <div class="card-footer">
                    ${!car.isSold
                        ? `<button class="btn btn-sm btn-outline-danger" onclick="removeCar('${car.id}')">🗑️ Remove Listing</button>`
                        : `<span class="text-muted small">This car has been sold.</span>`
                    }
                </div>
            </div>
        `;

        // Append the card to the container (appendChild - DOM lab)
        container.appendChild(col);
    }

    productsVisible = true;  // Mark as visible

} // End of loadMyListings()


/* -----------------------------------------------------------------------
   FUNCTION: previewImage
   PURPOSE : Show a preview of the uploaded car photo immediately
   PARAM   : event - the file input change event
   USES    : FileReader API, Event concept (event.js), DOM manipulation
   ----------------------------------------------------------------------- */
function previewImage(event) {

    // event.target.files is the list of selected files
    const file = event.target.files[0];  // Get the first (only) file

    if (!file) return;  // If no file selected, stop

    // FileReader is a built-in JS object that reads files
    const reader = new FileReader();

    // onload is called when FileReader finishes reading the file
    // This is an event handler concept (event.js)
    reader.onload = function(e) {
        const preview = document.getElementById("carPhotoPreview");

        if (preview) {
            preview.src = e.target.result;     // Set image source to file data
            preview.classList.remove("d-none"); // Show the preview image
        }
    };

    // Read the file as a data URL (base64 encoded string)
    reader.readAsDataURL(file);

} // End of previewImage()


/* -----------------------------------------------------------------------
   FUNCTION: addNewCar
   PURPOSE : Collects form data, validates it, and adds new car to storage
   USES    : Object creation, Array.push(), DOM .value property, Conditionals
   ----------------------------------------------------------------------- */
function addNewCar() {

    const user = getCurrentUser();
    if (!user) {
        window.location.href = "login.html";
        return;
    }

    // ---- Read all form field values (DOM .value property) ----
    const ownerName   = document.getElementById("ownerName").value.trim();
    const carContact  = document.getElementById("carContact").value.trim();
    const carBrand    = document.getElementById("carBrand").value;
    const carModel    = document.getElementById("carModel").value.trim();
    const carYear     = document.getElementById("carYear").value;
    const carCondition = document.getElementById("carCondition").value;
    const carKm       = document.getElementById("carKm").value;
    const carPrice    = document.getElementById("carPrice").value;
    const carAddress  = document.getElementById("carAddress").value.trim();
    const carDesc     = document.getElementById("carDescription").value.trim();
    const photoInput  = document.getElementById("carPhoto");

    // ---- Form Validation (Conditional chain) ----
    if (ownerName === "") {
        showAddCarAlert("⚠️ Please enter the owner's name.", "warning"); return;
    }
    if (carContact === "" || carContact.length !== 10) {
        showAddCarAlert("⚠️ Please enter a valid 10-digit contact number.", "warning"); return;
    }
    if (carBrand === "") {
        showAddCarAlert("⚠️ Please select a car brand.", "warning"); return;
    }
    if (carModel === "") {
        showAddCarAlert("⚠️ Please enter the car model.", "warning"); return;
    }
    if (carYear === "" || carYear < 1990 || carYear > 2026) {
        showAddCarAlert("⚠️ Please enter a valid year (1990-2026).", "warning"); return;
    }
    if (carCondition === "") {
        showAddCarAlert("⚠️ Please select the car condition.", "warning"); return;
    }
    if (carKm === "" || carKm < 0) {
        showAddCarAlert("⚠️ Please enter valid kilometers driven.", "warning"); return;
    }
    if (carPrice === "" || carPrice <= 0) {
        showAddCarAlert("⚠️ Please enter a valid price.", "warning"); return;
    }
    if (carAddress === "") {
        showAddCarAlert("⚠️ Please enter the car's location.", "warning"); return;
    }

    // ---- Get photo as base64 string (if uploaded) ----
    // We read from the preview image src which is already set by previewImage()
    const previewImg = document.getElementById("carPhotoPreview");
    const photoData  = previewImg && !previewImg.classList.contains("d-none")
                        ? previewImg.src
                        : "";

    // ---- Create New Car Object (Object concept from Lab 4 - object.js) ----
    const newCar = {
        id:          generateId("car"),      // Unique ID from data.js
        ownerId:     user.id,                // Link car to current user
        ownerName:   ownerName,
        contact:     carContact,
        brand:       carBrand,
        model:       carModel,
        year:        parseInt(carYear),      // Convert string to integer
        condition:   carCondition,
        km:          parseInt(carKm),
        price:       parseInt(carPrice),
        address:     carAddress,
        description: carDesc,
        photo:       photoData,
        isSold:      false,                   // New listing = not sold
        listedDate:  new Date().toLocaleDateString("en-IN")  // Today's date
    };

    // ---- Add car to array and save ----
    const allCars = getAllCars();
    allCars.push(newCar);  // Array.push() from Lab 4
    saveCars(allCars);     // Save back to localStorage

    // Update live navbar badge
    if (typeof renderLiveNavbar === "function") renderLiveNavbar();

    // ---- Show success message ----
    showAddCarAlert("✅ Car listed successfully! Check 'My Car Listings' tab.", "success");

    // ---- Reset the form ----
    resetCarForm();

    // Refresh the listings tab
    loadMyListings();

} // End of addNewCar()


/* -----------------------------------------------------------------------
   FUNCTION: showAddCarAlert
   PURPOSE : Shows alert inside the Add Car form
   ----------------------------------------------------------------------- */
function showAddCarAlert(message, type) {
    const alertEl = document.getElementById("addCarAlert");
    if (alertEl) {
        alertEl.className = "alert alert-" + type;
        alertEl.textContent = message;
    }
}


/* -----------------------------------------------------------------------
   FUNCTION: resetCarForm
   PURPOSE : Clears all inputs in the Add Car form after successful submission
   USES    : DOM value property = ""
   ----------------------------------------------------------------------- */
function resetCarForm() {
    // Set all input values to empty string
    const fields = ["ownerName", "carContact", "carBrand", "carModel", "carYear",
                    "carCondition", "carKm", "carPrice", "carAddress", "carDescription", "carPhoto"];

    // for...of loop (Lab 2) to reset each field
    for (let fieldId of fields) {
        const field = document.getElementById(fieldId);
        if (field) field.value = "";
    }

    // Hide the photo preview
    const preview = document.getElementById("carPhotoPreview");
    if (preview) {
        preview.src = "";
        preview.classList.add("d-none");
    }
}


/* -----------------------------------------------------------------------
   FUNCTION: removeCar
   PURPOSE : Remove a car listing (only available if car is not sold)
   PARAM   : carId - ID of the car to remove
   USES    : Array.filter(), conditional
   ----------------------------------------------------------------------- */
function removeCar(carId) {

    // Confirm before deleting (built-in browser confirm dialog)
    const confirmed = confirm("Are you sure you want to remove this car listing?");
    if (!confirmed) return;  // User clicked Cancel

    // Get all cars and filter out the one with matching id
    // Array.filter() from Lab 4 (array.js)
    const allCars = getAllCars();
    const updated = allCars.filter(function(car) {
        return car.id !== carId;  // Keep all cars EXCEPT the one being removed
    });

    saveCars(updated);    // Save updated array
    loadMyListings();     // Refresh the listings display

} // End of removeCar()


/* -----------------------------------------------------------------------
   FUNCTION: loadMyServices
   PURPOSE : Shows the current user's service requests and their status
   USES    : Array.filter(), for...of loop, DOM innerHTML, statusBadge
   ----------------------------------------------------------------------- */
function loadMyServices() {

    const user = getCurrentUser();
    if (!user) return;

    const container = document.getElementById("myServiceContainer");
    const noMsg     = document.getElementById("noServicesMsg");

    if (!container) return;

    // Get all services, filter to only THIS user's services
    const allServices  = getAllServices();
    const myServices   = allServices.filter(function(svc) {
        return svc.userId === user.id;
    });

    // Clear container
    container.innerHTML = "";

    // If no services, show message
    if (myServices.length === 0) {
        if (noMsg) noMsg.classList.remove("d-none");
        return;
    }

    if (noMsg) noMsg.classList.add("d-none");

    // for...of loop to render each service card
    for (let svc of myServices) {

        // Determine badge color based on status
        let badgeClass = "bg-warning text-dark";

        // Conditional chain (if-else)
        if (svc.status === "Completed - Car Delivered") {
            badgeClass = "bg-success";
        } else if (svc.status.includes("Shipped")) {
            badgeClass = "bg-info text-dark";
        } else if (svc.status.includes("Garage")) {
            badgeClass = "bg-primary";
        } else if (svc.status === "Pending - Mechanic Assigned") {
            badgeClass = "bg-warning text-dark";
        }

        const col = document.createElement("div");
        col.className = "col-12 col-md-6";

        col.innerHTML = `
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold">🔧 Service Request</span>
                    <span class="badge ${badgeClass}">${svc.status}</span>
                </div>
                <div class="card-body">
                    <p class="mb-1"><strong>Car:</strong> ${svc.carBrand} ${svc.carModel}</p>
                    <p class="mb-1"><strong>Reg No:</strong> ${svc.carReg}</p>
                    <p class="mb-1"><strong>Problem:</strong> ${svc.problem}</p>
                    <p class="mb-1"><strong>Location:</strong> ${svc.location}</p>
                    <p class="mb-1"><strong>Alternate Car:</strong> ${svc.needsAlternateCar ? "✅ Yes" : "❌ No"}</p>
                    <p class="text-muted small"><strong>Requested On:</strong> ${svc.date}</p>
                </div>
                <div class="card-footer text-muted small">
                    🕐 Status is updated by Admin
                </div>
            </div>
        `;

        container.appendChild(col);
    }

} // End of loadMyServices()


/* -----------------------------------------------------------------------
   PAGE LOAD - Initialize dashboard when DOM is ready
   DOMContentLoaded event (event.js)
   ----------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function() {

    // Protect page: redirect to login if not logged in
    if (!isLoggedIn()) {
        window.location.href = "login.html";
        return;
    }

    // Redirect admin to admin panel
    if (isAdmin()) {
        window.location.href = "admin.html";
        return;
    }

    // Set welcome message using DOM textContent (firstdom.js)
    const user         = getCurrentUser();
    const welcomeName  = document.getElementById("welcomeName");
    const dashUserName = document.getElementById("dashUserName");
    const dashLogout   = document.getElementById("dashLogout");

    if (welcomeName)  welcomeName.textContent  = user.name;
    if (dashUserName) dashUserName.textContent = "👤 " + user.name;

    // Attach logout event using addEventListener (event.js)
    if (dashLogout) {
        dashLogout.addEventListener("click", function(e) {
            e.preventDefault();
            logout();
        });
    }

    // Load my listings on default tab
    loadMyListings();

    console.log("✅ dashboard.js loaded for user:", user.name);
});

