/* =====================================================================
   FILE: admin.js
   PURPOSE: Admin Panel logic (admin.html)
            - Verify admin access
            - Display all users, all car listings, all service requests
            - Allow admin to update service status
            - Allow admin to mark cars as sold
            - Update global stats (total deals, total services)

   CONCEPTS USED FROM CLASS:
   - Objects (Lab 4 - object.js)
   - Arrays + methods: filter(), find(), forEach() (Lab 4 - array.js)
   - Functions & Arrow Functions (Lab 3 - function.js)
   - DOM createElement(), appendChild(), innerHTML, textContent (firstdom.js)
   - Events - addEventListener, onclick (event.js)
   - Conditional Statements (Lecture 3 - condt_stat.js)
   - for...of loop, for loop (Lab 2 - loop.js)
   - Destructuring (Lab 5 - destructuring.js)
   - Classes & Objects (Lab 4 - object.js class concept)
   ===================================================================== */


/* -----------------------------------------------------------------------
   FUNCTION: showAdminTab
   PURPOSE : Toggle between admin tabs (Users, Cars, Services)
   PARAM   : tabName - string name of tab to show
   ----------------------------------------------------------------------- */
function showAdminTab(tabName) {

    // Array of all tab section ids
    const allTabs = ["allUsers", "allCars", "allServices"];

    // for...of loop (Lab 2) to hide all sections
    for (let tab of allTabs) {
        const el = document.getElementById(tab);
        if (el) el.classList.add("d-none");
    }

    // Show selected tab
    const selected = document.getElementById(tabName);
    if (selected) selected.classList.remove("d-none");

    // Load respective data when tab is shown
    if (tabName === "allUsers")    loadAllUsers();
    if (tabName === "allCars")     loadAllCarsAdmin();
    if (tabName === "allServices") loadAllServicesAdmin();

} // End of showAdminTab()


/* -----------------------------------------------------------------------
   FUNCTION: loadAdminStats
   PURPOSE : Show summary stats at the top of admin panel
   USES    : DOM createElement, innerHTML, Array.length
   ----------------------------------------------------------------------- */
function loadAdminStats() {

    const statsDiv = document.getElementById("adminStats");
    if (!statsDiv) return;

    // Get data using data.js functions
    const allUsers    = getAllUsers();
    const allCars     = getAllCars();
    const allServices = getAllServices();
    const stats       = getStats();

    // Count only non-admin users
    let userCount = 0;
    for (let u of allUsers) {          // for...of loop (Lab 2)
        if (u.role !== "admin") userCount++;
    }

    // Count unsold and sold cars separately using Array.filter()
    const unsoldCars = allCars.filter(car => car.isSold === false);
    const soldCars   = allCars.filter(car => car.isSold === true);

    // Count pending and completed services
    const pendingServices   = allServices.filter(s => s.status !== "Completed - Car Delivered");
    const completedServices = allServices.filter(s => s.status === "Completed - Car Delivered");

    // Array of stat card data (Array of Objects - Lab 4)
    const statItems = [
        { label: "Total Users",         value: userCount,                 icon: "👥", color: "bg-primary"  },
        { label: "Cars Listed",         value: allCars.length,            icon: "🚗", color: "bg-info"     },
        { label: "Successful Deals",    value: stats.totalDeals,          icon: "🤝", color: "bg-success"  },
        { label: "Active Services",     value: pendingServices.length,    icon: "🔧", color: "bg-warning"  },
        { label: "Completed Services",  value: completedServices.length,  icon: "✅", color: "bg-success"  },
        { label: "Cars Sold",           value: soldCars.length,           icon: "💰", color: "bg-danger"   }
    ];

    statsDiv.innerHTML = "";  // Clear before rendering

    // for...of loop to render each stat card
    for (let item of statItems) {
        const col = document.createElement("div");
        col.className = "col-6 col-md-4 col-lg-2";

        col.innerHTML = `
            <div class="card text-white ${item.color} shadow-sm text-center p-3">
                <div style="font-size:1.8rem;">${item.icon}</div>
                <div class="fs-3 fw-bold">${item.value}</div>
                <small>${item.label}</small>
            </div>
        `;

        statsDiv.appendChild(col);  // DOM appendChild() (firstdom.js)
    }

} // End of loadAdminStats()


/* -----------------------------------------------------------------------
   FUNCTION: loadAllUsers
   PURPOSE : Display all registered users in a table
   USES    : getAllUsers(), for loop, DOM innerHTML
   ----------------------------------------------------------------------- */
function loadAllUsers() {

    const tbody = document.getElementById("usersTableBody");
    if (!tbody) return;

    const users = getAllUsers();  // data.js

    // Clear table body
    tbody.innerHTML = "";

    // for loop with index counter (Lab 2 - loop.js)
    for (let i = 0; i < users.length; i++) {

        const user = users[i];  // Get user object at index i

        // Create table row element
        const row = document.createElement("tr");

        // Role badge: admin gets red, user gets green
        const roleBadge = user.role === "admin"
            ? `<span class="badge bg-danger">Admin</span>`
            : `<span class="badge bg-success">User</span>`;

        row.innerHTML = `
            <td>${i + 1}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.phone}</td>
            <td>${roleBadge}</td>
        `;

        tbody.appendChild(row);
    }

} // End of loadAllUsers()


/* -----------------------------------------------------------------------
   FUNCTION: loadAllCarsAdmin
   PURPOSE : Display ALL car listings (sold + unsold) for admin
   USES    : getAllCars(), for...of loop, DOM innerHTML
   ----------------------------------------------------------------------- */
function loadAllCarsAdmin() {

    const container = document.getElementById("adminCarContainer");
    if (!container) return;

    const allCars = getAllCars();
    container.innerHTML = "";

    // If no cars at all, show message
    if (allCars.length === 0) {
        container.innerHTML = `<div class="col-12"><p class="text-muted">No car listings found.</p></div>`;
        return;
    }

    // for...of loop to render each car card
    for (let car of allCars) {

        const col = document.createElement("div");
        col.className = "col-12 col-md-6 col-lg-4";

        // Sold status badge (Conditional / Ternary - Lecture 3)
        const soldBadge = car.isSold
            ? `<span class="badge bg-secondary">Sold</span>`
            : `<span class="badge bg-success">Available</span>`;

        col.innerHTML = `
            <div class="card shadow-sm h-100">
                ${car.photo ? `<img src="${car.photo}" alt="Car" class="card-img-top" style="height:180px;object-fit:cover;">` : ''}
                <div class="card-header d-flex justify-content-between">
                    <span class="fw-bold">${car.brand} ${car.model} (${car.year})</span>
                    ${soldBadge}
                </div>
                <div class="card-body">
                    <p class="mb-1"><strong>Owner:</strong> ${car.ownerName}</p>
                    <p class="mb-1"><strong>Contact:</strong> ${car.contact}</p>
                    <p class="mb-1"><strong>Condition:</strong> ${car.condition}</p>
                    <p class="mb-1"><strong>KM:</strong> ${Number(car.km).toLocaleString("en-IN")} km</p>
                    <p class="mb-1"><strong>Location:</strong> ${car.address}</p>
                    <p class="text-success fw-bold">${formatINR(car.price)}</p>
                </div>
                <div class="card-footer">
                    ${!car.isSold
                        ? `<button class="btn btn-sm btn-success" onclick="openMarkSoldModal('${car.id}')">
                               ✅ Mark as Sold
                           </button>`
                        : `<span class="text-muted small">Already sold.</span>`
                    }
                </div>
            </div>
        `;

        container.appendChild(col);
    }

} // End of loadAllCarsAdmin()


/* -----------------------------------------------------------------------
   FUNCTION: openMarkSoldModal
   PURPOSE : Opens Bootstrap modal to confirm marking car as sold
   PARAM   : carId - ID of the car to mark as sold
   ----------------------------------------------------------------------- */
function openMarkSoldModal(carId) {

    // Store the carId in the hidden input inside modal
    // DOM getElementById + value (firstdom.js)
    const hiddenInput = document.getElementById("markSoldCarId");
    if (hiddenInput) hiddenInput.value = carId;

    // Open Bootstrap Modal
    const modalEl = document.getElementById("markSoldModal");
    const modal   = new bootstrap.Modal(modalEl);
    modal.show();

} // End of openMarkSoldModal()


/* -----------------------------------------------------------------------
   FUNCTION: markCarAsSold
   PURPOSE : Marks a car as sold, updates stats, closes modal
   USES    : Array.find(), Object property update, saveStats()
   ----------------------------------------------------------------------- */
function markCarAsSold() {

    // Get the car ID from hidden input
    const carId = document.getElementById("markSoldCarId").value;

    if (!carId) return;

    // Get all cars array
    const allCars = getAllCars();

    // Find the car by its ID using Array.find() (Lab 4)
    // Destructuring concept: we can directly get the car object reference
    const car = allCars.find(function(c) {
        return c.id === carId;
    });

    // Conditional: if car not found, stop
    if (!car) {
        alert("Car not found!");
        return;
    }

    // Update the car's isSold property (Object property update - Lab 4)
    car.isSold = true;

    // Save updated cars array
    saveCars(allCars);

    // ---- Update Stats: increment totalDeals ----
    const stats = getStats();
    stats.totalDeals = stats.totalDeals + 1;  // Increment by 1
    saveStats(stats);

    // Close the modal
    const modalEl = document.getElementById("markSoldModal");
    const modal   = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();

    // Refresh admin view
    loadAllCarsAdmin();
    loadAdminStats();

    alert("✅ Car marked as sold! Total deals updated.");

} // End of markCarAsSold()


/* -----------------------------------------------------------------------
   FUNCTION: loadAllServicesAdmin
   PURPOSE : Display ALL service requests with option to update status
   USES    : getAllServices(), for...of loop, DOM innerHTML
   ----------------------------------------------------------------------- */
function loadAllServicesAdmin() {

    const container = document.getElementById("adminServiceContainer");
    if (!container) return;

    const allServices = getAllServices();
    container.innerHTML = "";

    // If no services at all
    if (allServices.length === 0) {
        container.innerHTML = `<div class="col-12"><p class="text-muted">No service requests yet.</p></div>`;
        return;
    }

    // for...of loop to render each service card
    for (let svc of allServices) {

        // Determine badge color based on current status
        let badgeClass = "bg-warning text-dark";

        if (svc.status === "Completed - Car Delivered") {
            badgeClass = "bg-success";
        } else if (svc.status.includes("Shipped")) {
            badgeClass = "bg-info text-dark";
        } else if (svc.status.includes("Garage")) {
            badgeClass = "bg-primary";
        }

        const col = document.createElement("div");
        col.className = "col-12 col-md-6";

        col.innerHTML = `
            <div class="card shadow-sm h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold">🔧 ${svc.name}</span>
                    <span class="badge ${badgeClass}">${svc.status}</span>
                </div>
                <div class="card-body">
                    <p class="mb-1"><strong>User:</strong> ${svc.userName} (${svc.userEmail})</p>
                    <p class="mb-1"><strong>Car:</strong> ${svc.carBrand} ${svc.carModel}</p>
                    <p class="mb-1"><strong>Reg No:</strong> ${svc.carReg}</p>
                    <p class="mb-1"><strong>Phone:</strong> ${svc.phone}</p>
                    <p class="mb-1"><strong>Problem:</strong> ${svc.problem}</p>
                    <p class="mb-1"><strong>Location:</strong> ${svc.location}</p>
                    <p class="mb-1"><strong>Alternate Car:</strong> ${svc.needsAlternateCar ? "✅ Yes" : "❌ No"}</p>
                    <p class="text-muted small"><strong>Requested On:</strong> ${svc.date}</p>
                </div>
                <div class="card-footer">
                    ${svc.status !== "Completed - Car Delivered"
                        ? `<button class="btn btn-sm btn-danger" onclick="openStatusModal('${svc.id}')">
                               🔄 Update Status
                           </button>`
                        : `<span class="text-success small fw-bold">✅ Service Completed</span>`
                    }
                </div>
            </div>
        `;

        container.appendChild(col);
    }

} // End of loadAllServicesAdmin()


/* -----------------------------------------------------------------------
   FUNCTION: openStatusModal
   PURPOSE : Opens Bootstrap modal for updating service status
   PARAM   : serviceId - ID of the service request to update
   ----------------------------------------------------------------------- */
function openStatusModal(serviceId) {

    // Store service ID in hidden input (DOM .value)
    const hiddenInput = document.getElementById("updateServiceId");
    if (hiddenInput) hiddenInput.value = serviceId;

    // Open Bootstrap Modal (Lab 10 - main.html Bootstrap Modal concept)
    const modalEl = document.getElementById("statusModal");
    const modal   = new bootstrap.Modal(modalEl);
    modal.show();

} // End of openStatusModal()


/* -----------------------------------------------------------------------
   FUNCTION: updateServiceStatus
   PURPOSE : Updates the status of a service request (Admin only)
             Also updates totalServices stat if status = Completed
   USES    : Array.find(), Object property update, saveServices(), saveStats()
   ----------------------------------------------------------------------- */
function updateServiceStatus() {

    // Get the service ID from hidden input
    const serviceId = document.getElementById("updateServiceId").value;

    // Get selected status from radio buttons
    // querySelectorAll returns all matching elements (DOM concept)
    const selectedRadio = document.querySelector("input[name='statusOption']:checked");

    // Validation: must select a status
    if (!selectedRadio) {
        alert("⚠️ Please select a status before updating.");
        return;
    }

    const newStatus = selectedRadio.value;  // Get value of selected radio

    // ---- Find and update the service ----
    const allServices = getAllServices();

    // Array.find() to locate the service (Lab 4 - array.js)
    const service = allServices.find(function(s) {
        return s.id === serviceId;
    });

    if (!service) {
        alert("Service not found!");
        return;
    }

    // Update status (Object property assignment - Lab 4)
    service.status = newStatus;
    saveServices(allServices);

    // ---- If marked as Completed, increment totalServices stat ----
    if (newStatus === "Completed - Car Delivered") {
        const stats = getStats();
        stats.totalServices = stats.totalServices + 1;  // Increment
        saveStats(stats);
    }

    // Close the modal
    const modalEl = document.getElementById("statusModal");
    const modal   = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();

    // Uncheck radio buttons for next time
    const allRadios = document.querySelectorAll("input[name='statusOption']");
    for (let radio of allRadios) {
        radio.checked = false;
    }

    // Refresh the services list
    loadAllServicesAdmin();
    loadAdminStats();

    alert("✅ Service status updated to: " + newStatus);

} // End of updateServiceStatus()


/* -----------------------------------------------------------------------
   PAGE LOAD - Initialize admin panel when DOM is ready
   DOMContentLoaded event (event.js)
   ----------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function() {

    const accessDenied = document.getElementById("accessDenied");
    const adminContent = document.getElementById("adminContent");

    // ---- Access Control: Only Admin can see this page ----
    // isAdmin() from auth.js
    if (!isAdmin()) {
        // Show access denied, hide admin content
        if (accessDenied) accessDenied.classList.remove("d-none");
        if (adminContent) adminContent.classList.add("d-none");
        return;
    }

    // Admin is verified: show admin content
    if (adminContent) adminContent.classList.remove("d-none");

    // Attach logout event (Events concept - event.js)
    const logoutBtn = document.getElementById("adminLogout");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function(e) {
            e.preventDefault();
            logout();   // auth.js logout function
        });
    }

    // Load stats and default tab (Users)
    loadAdminStats();
    loadAllUsers();

    console.log("✅ admin.js loaded. Admin access verified.");
});
