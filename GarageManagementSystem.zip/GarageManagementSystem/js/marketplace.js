/* =====================================================================
   FILE: marketplace.js
   PURPOSE: Car Marketplace page logic (marketplace.html)
            - Load and display available (unsold) cars as cards
            - Search and filter cars by brand, model, condition
            - Open car detail modal with full info
            - Show car price in INR format

   CONCEPTS USED FROM CLASS:
   - Arrays + Array methods filter() (Lab 4 - array.js)
   - Objects (Lab 4 - object.js)
   - Functions & Arrow Functions (Lab 3 - function.js)
   - DOM createElement(), appendChild(), textContent, innerHTML (firstdom.js)
   - Events - oninput, onchange, addEventListener (event.js)
   - Conditional Statements (Lecture 3 - condt_stat.js)
   - for...of loop (Lab 2 - loop.js)
   - String methods: .toLowerCase(), .includes()
   ===================================================================== */


/* -----------------------------------------------------------------------
   FUNCTION: loadMarketplace
   PURPOSE : Fetches all available cars and displays them as Bootstrap cards
   USES    : getAvailableCars() from data.js, DOM manipulation, for...of loop
   ----------------------------------------------------------------------- */
function loadMarketplace() {

    const container = document.getElementById("marketplaceContainer");
    const noCarsMsg = document.getElementById("noCarsMsg");
    const carCount  = document.getElementById("carCount");

    if (!container) return;

    // getAvailableCars() from data.js returns only cars where isSold === false
    const availableCars = getAvailableCars();

    // Update count display
    if (carCount) carCount.textContent = availableCars.length;

    // Clear existing cards
    container.innerHTML = "";

    // If no cars available, show the no-cars message
    if (availableCars.length === 0) {
        if (noCarsMsg) noCarsMsg.classList.remove("d-none");
        return;
    }

    if (noCarsMsg) noCarsMsg.classList.add("d-none");

    // ---- Render each available car as a Bootstrap card ----
    // for...of loop from Lab 2 (loop.js)
    for (let car of availableCars) {

        // DOM createElement() from firstdom.js
        const col = document.createElement("div");
        col.className = "col-12 col-md-6 col-lg-4";

        // Determine condition badge color
        let conditionClass = "bg-success";  // Default = green
        // Conditional chain (Lecture 3)
        if (car.condition === "Good")         conditionClass = "bg-primary";
        if (car.condition === "Fair")         conditionClass = "bg-warning text-dark";
        if (car.condition === "Needs Repair") conditionClass = "bg-danger";

        // Car photo or placeholder if no photo
        const photoHTML = car.photo
            ? `<img src="${car.photo}" alt="${car.brand} ${car.model}" class="card-img-top" style="height:200px;object-fit:cover;">`
            : `<div class="car-photo-placeholder d-flex align-items-center justify-content-center">🚗</div>`;

        // Create card HTML using template literal (backtick strings)
        col.innerHTML = `
            <div class="card h-100 shadow car-card">
                ${photoHTML}
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0 fw-bold">${car.brand} ${car.model}</h5>
                        <span class="badge ${conditionClass}">${car.condition}</span>
                    </div>
                    <p class="text-success fw-bold fs-5 mb-1">${formatINR(car.price)}</p>
                    <p class="text-muted small mb-1">📅 Year: ${car.year} &nbsp;|&nbsp; 🛣️ ${Number(car.km).toLocaleString("en-IN")} km</p>
                    <p class="text-muted small mb-2">📍 ${car.address}</p>
                    <p class="card-text text-muted small" style="min-height:40px;">${car.description.substring(0, 80)}${car.description.length > 80 ? "..." : ""}</p>
                </div>
                <div class="card-footer d-flex justify-content-between align-items-center">
                    <span class="small text-muted">📞 ${car.contact}</span>
                    <button class="btn btn-primary btn-sm" onclick="openCarDetail('${car.id}')">
                        View Details
                    </button>
                </div>
            </div>
        `;

        // Append card to container (appendChild from firstdom.js)
        container.appendChild(col);
    }

} // End of loadMarketplace()


/* -----------------------------------------------------------------------
   FUNCTION: filterCars
   PURPOSE : Filter displayed cars based on search input and dropdown filters
   USES    : Array.filter(), String methods (.toLowerCase, .includes)
             This runs every time user types in search box or changes filters
   ----------------------------------------------------------------------- */
function filterCars() {

    // Read search and filter values from inputs
    const searchInput   = document.getElementById("searchInput").value.toLowerCase().trim();
    const filterBrand   = document.getElementById("filterBrand").value;
    const filterCondition = document.getElementById("filterCondition").value;

    const container = document.getElementById("marketplaceContainer");
    const noCarsMsg = document.getElementById("noCarsMsg");
    const carCount  = document.getElementById("carCount");

    // Get all available (unsold) cars
    const availableCars = getAvailableCars();

    // ---- Apply all filters using Array.filter() ----
    // filter() goes through each car and keeps it ONLY if all conditions pass
    const filtered = availableCars.filter(function(car) {

        // Search filter: check if brand or model contains search keyword
        // String .toLowerCase() + .includes() method concept
        const matchSearch = searchInput === "" ||
                            car.brand.toLowerCase().includes(searchInput) ||
                            car.model.toLowerCase().includes(searchInput) ||
                            car.address.toLowerCase().includes(searchInput);

        // Brand filter: match exact brand or "All Brands" selected
        const matchBrand = filterBrand === "" || car.brand === filterBrand;

        // Condition filter: match exact condition or "All Conditions" selected
        const matchCondition = filterCondition === "" || car.condition === filterCondition;

        // Logical AND (&&) from Lecture 2 - all conditions must be true
        return matchSearch && matchBrand && matchCondition;
    });

    // Clear container
    container.innerHTML = "";

    // Update count
    if (carCount) carCount.textContent = filtered.length;

    // If no results, show no-cars message
    if (filtered.length === 0) {
        if (noCarsMsg) noCarsMsg.classList.remove("d-none");
        return;
    }

    if (noCarsMsg) noCarsMsg.classList.add("d-none");

    // Render filtered cars
    // for...of loop (Lab 2)
    for (let car of filtered) {

        let conditionClass = "bg-success";
        if (car.condition === "Good")         conditionClass = "bg-primary";
        if (car.condition === "Fair")         conditionClass = "bg-warning text-dark";
        if (car.condition === "Needs Repair") conditionClass = "bg-danger";

        const photoHTML = car.photo
            ? `<img src="${car.photo}" alt="${car.brand} ${car.model}" class="card-img-top" style="height:200px;object-fit:cover;">`
            : `<div class="car-photo-placeholder d-flex align-items-center justify-content-center">🚗</div>`;

        const col = document.createElement("div");
        col.className = "col-12 col-md-6 col-lg-4";

        col.innerHTML = `
            <div class="card h-100 shadow car-card">
                ${photoHTML}
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0 fw-bold">${car.brand} ${car.model}</h5>
                        <span class="badge ${conditionClass}">${car.condition}</span>
                    </div>
                    <p class="text-success fw-bold fs-5 mb-1">${formatINR(car.price)}</p>
                    <p class="text-muted small mb-1">📅 Year: ${car.year} &nbsp;|&nbsp; 🛣️ ${Number(car.km).toLocaleString("en-IN")} km</p>
                    <p class="text-muted small mb-2">📍 ${car.address}</p>
                    <p class="card-text text-muted small">${car.description.substring(0, 80)}${car.description.length > 80 ? "..." : ""}</p>
                </div>
                <div class="card-footer d-flex justify-content-between align-items-center">
                    <span class="small text-muted">📞 ${car.contact}</span>
                    <button class="btn btn-primary btn-sm" onclick="openCarDetail('${car.id}')">View Details</button>
                </div>
            </div>
        `;

        container.appendChild(col);
    }

} // End of filterCars()


/* -----------------------------------------------------------------------
   FUNCTION: resetFilters
   PURPOSE : Clear all search/filter inputs and reload all cars
   ----------------------------------------------------------------------- */
function resetFilters() {

    // Reset input values to empty/default (DOM .value property)
    document.getElementById("searchInput").value    = "";
    document.getElementById("filterBrand").value    = "";
    document.getElementById("filterCondition").value = "";

    // Reload the marketplace with no filters
    loadMarketplace();

} // End of resetFilters()


/* -----------------------------------------------------------------------
   FUNCTION: openCarDetail
   PURPOSE : Opens a Bootstrap modal showing full details of a selected car
   PARAM   : carId - the ID of the car to show details for
   USES    : Array.find(), Bootstrap Modal, DOM innerHTML, Object properties
   ----------------------------------------------------------------------- */
function openCarDetail(carId) {

    // Find the car by its ID in the cars array
    // Array.find() from Lab 4 (array.js)
    const allCars  = getAllCars();
    const car      = allCars.find(function(c) {
        return c.id === carId;
    });

    // If car not found, stop
    if (!car) return;

    // Get modal elements by ID
    const modalTitle = document.getElementById("modalCarTitle");
    const modalBody  = document.getElementById("modalCarBody");

    if (modalTitle) modalTitle.textContent = car.brand + " " + car.model + " (" + car.year + ")";

    // Build detailed car info HTML for modal body
    if (modalBody) {
        modalBody.innerHTML = `
            <div class="row">
                <div class="col-12 col-md-5">
                    ${car.photo
                        ? `<img src="${car.photo}" alt="Car Photo" class="img-fluid rounded" style="width:100%;max-height:220px;object-fit:cover;">`
                        : `<div class="car-photo-placeholder-lg d-flex align-items-center justify-content-center rounded" style="height:200px;background:#f0f0f0;font-size:4rem;">🚗</div>`
                    }
                </div>
                <div class="col-12 col-md-7">
                    <table class="table table-sm table-borderless">
                        <tr><td class="fw-bold">Price:</td><td class="text-success fw-bold fs-5">${formatINR(car.price)}</td></tr>
                        <tr><td class="fw-bold">Brand:</td><td>${car.brand}</td></tr>
                        <tr><td class="fw-bold">Model:</td><td>${car.model}</td></tr>
                        <tr><td class="fw-bold">Year:</td><td>${car.year}</td></tr>
                        <tr><td class="fw-bold">Condition:</td><td>${car.condition}</td></tr>
                        <tr><td class="fw-bold">KM Driven:</td><td>${Number(car.km).toLocaleString("en-IN")} km</td></tr>
                        <tr><td class="fw-bold">Owner:</td><td>${car.ownerName}</td></tr>
                        <tr><td class="fw-bold">Contact:</td><td>📞 ${car.contact}</td></tr>
                        <tr><td class="fw-bold">Location:</td><td>📍 ${car.address}</td></tr>
                        <tr><td class="fw-bold">Listed On:</td><td>${car.listedDate}</td></tr>
                    </table>
                </div>
            </div>
            ${car.description ? `<div class="mt-3"><strong>Description:</strong><p class="text-muted mt-1">${car.description}</p></div>` : ""}
        `;
    }

    // Open the Bootstrap modal using JS
    // Bootstrap Modal concept from Lab 10 (main.html)
    const modalElement = document.getElementById("carDetailModal");
    const modal = new bootstrap.Modal(modalElement);
    modal.show();

} // End of openCarDetail()


/* -----------------------------------------------------------------------
   PAGE LOAD - Initialize marketplace when DOM is ready
   DOMContentLoaded event (event.js)
   ----------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function() {
    loadMarketplace();  // Load cars on page open
    console.log("✅ marketplace.js loaded.");
});
