/* =====================================================================
   FILE: login.js
   PURPOSE: Handles Login and Sign Up form logic on login.html
            - Form validation
            - User registration (Sign Up)
            - User login authentication

   CONCEPTS USED FROM CLASS:
   - Functions (Lab 3 - function.js)
   - Conditional Statements (Lecture 3 - condt_stat.js)
   - Objects (Lab 4 - object.js)
   - Array methods: push(), find() (Lab 4 - array.js)
   - DOM manipulation (JS - DOM - firstdom.js)
   - Events (Events in JS - event.js)
   ===================================================================== */


/* -----------------------------------------------------------------------
   FUNCTION: showTab
   PURPOSE : Toggle between Login and Sign Up tab on login.html
   PARAM   : tabName - either "login" or "signup"
   USES    : DOM classList manipulation (from firstdom.js concepts)
   ----------------------------------------------------------------------- */
function showTab(tabName) {

    // Get both form containers by their id (getElementById from DOM lab)
    const loginForm  = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");

    // Get tab buttons
    const loginTab  = document.getElementById("loginTab");
    const signupTab = document.getElementById("signupTab");

    // Conditional statement (if-else) from Lecture 3
    if (tabName === "login") {

        // Show login form, hide signup form
        loginForm.classList.remove("d-none");
        signupForm.classList.add("d-none");

        // Update active tab button style
        loginTab.classList.add("active");
        signupTab.classList.remove("active");

    } else {

        // Show signup form, hide login form
        signupForm.classList.remove("d-none");
        loginForm.classList.add("d-none");

        // Update active tab button style
        signupTab.classList.add("active");
        loginTab.classList.remove("active");

    }

} // End of showTab()


/* -----------------------------------------------------------------------
   FUNCTION: showAlert
   PURPOSE : Show alert messages inside the form (success or error)
   PARAMS  : alertId   - id of the alert div element
             message   - message text to show
             alertType - "success" or "danger" (Bootstrap color classes)
   USES    : DOM textContent / classList (firstdom.js)
   ----------------------------------------------------------------------- */
function showAlert(alertId, message, alertType) {

    // Get the alert element
    const alertEl = document.getElementById(alertId);

    if (alertEl) {
        // Set message text
        alertEl.textContent = message;

        // Reset classes and apply correct Bootstrap alert type
        alertEl.className = "alert alert-" + alertType;
    }

} // End of showAlert()


/* -----------------------------------------------------------------------
   FUNCTION: handleLogin
   PURPOSE : Validates login form and authenticates user
   USES    : Array.find() - find user with matching email/password
             Objects, Conditional statements
   ----------------------------------------------------------------------- */
function handleLogin() {

    // Read values from input fields (DOM value property)
    const email    = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

    // ---- Form Validation ----
    // Conditional statements (Lecture 3 - condt_stat.js)
    if (email === "") {
        showAlert("loginAlert", "⚠️ Please enter your email address.", "danger");
        return;  // Stop function execution if validation fails
    }

    if (password === "") {
        showAlert("loginAlert", "⚠️ Please enter your password.", "danger");
        return;
    }

    // ---- Check credentials against stored users ----
    // getAllUsers() from data.js returns array of user objects
    const users = getAllUsers();

    // Array.find() method: searches array for first matching element
    // Returns the user object if found, otherwise undefined
    // Arrow function used inside find() (Lab 3 - function.js)
    const foundUser = users.find((user) => {
        // Logical AND (&&) from Lecture 2 - Logical Operators
        return user.email === email && user.password === password;
    });

    // Conditional: if user not found, show error
    if (!foundUser) {
        showAlert("loginAlert", "❌ Invalid email or password. Please try again.", "danger");
        return;
    }

    // ---- Login Success ----
    setCurrentUser(foundUser);  // Save logged-in user to session (auth.js)

    showAlert("loginAlert", "✅ Login successful! Redirecting...", "success");

    // Redirect based on user role (conditional from Lecture 3)
    // setTimeout delays the redirect so user sees the success message
    setTimeout(function() {
        if (foundUser.role === "admin") {
            window.location.href = "admin.html";     // Admin goes to admin panel
        } else {
            window.location.href = "dashboard.html"; // Normal user goes to dashboard
        }
    }, 1000);  // Wait 1000ms (1 second) before redirect

} // End of handleLogin()


/* -----------------------------------------------------------------------
   FUNCTION: handleSignup
   PURPOSE : Validates sign-up form and creates a new user account
   USES    : Array.push(), Array.find(), Objects, Conditional statements
   ----------------------------------------------------------------------- */
function handleSignup() {

    // Read all form field values (DOM .value property)
    const name            = document.getElementById("signupName").value.trim();
    const email           = document.getElementById("signupEmail").value.trim();
    const phone           = document.getElementById("signupPhone").value.trim();
    const password        = document.getElementById("signupPassword").value.trim();
    const confirmPassword = document.getElementById("signupConfirmPassword").value.trim();

    // ---- Form Validation (Conditional statements chain) ----

    // Check: Name must not be empty
    if (name === "") {
        showAlert("signupAlert", "⚠️ Please enter your full name.", "danger");
        return;
    }

    // Check: Email must not be empty
    if (email === "") {
        showAlert("signupAlert", "⚠️ Please enter your email address.", "danger");
        return;
    }

    // Check: Email must have valid format (contains @ symbol)
    if (!email.includes("@")) {
        showAlert("signupAlert", "⚠️ Please enter a valid email address.", "danger");
        return;
    }

    // Check: Phone must not be empty
    if (phone === "") {
        showAlert("signupAlert", "⚠️ Please enter your phone number.", "danger");
        return;
    }

    // Check: Phone must be 10 digits (phone.length property from Lab 4)
    if (phone.length !== 10) {
        showAlert("signupAlert", "⚠️ Phone number must be exactly 10 digits.", "danger");
        return;
    }

    // Check: Password minimum length
    if (password.length < 6) {
        showAlert("signupAlert", "⚠️ Password must be at least 6 characters.", "danger");
        return;
    }

    // Check: Passwords must match (comparison operator from Lecture 2)
    if (password !== confirmPassword) {
        showAlert("signupAlert", "⚠️ Passwords do not match.", "danger");
        return;
    }

    // ---- Check if email already registered ----
    const users = getAllUsers();

    // Array.find() to search for existing user with same email
    const existingUser = users.find(function(user) {
        return user.email === email;
    });

    if (existingUser) {
        showAlert("signupAlert", "❌ This email is already registered. Please login.", "danger");
        return;
    }

    // ---- Create New User Object (Object concept from Lab 4 - object.js) ----
    const newUser = {
        id:       generateId("user"),  // Unique ID using generateId() from data.js
        name:     name,
        email:    email,
        phone:    phone,
        password: password,
        role:     "user"               // All new registrations are 'user' (not admin)
    };

    // ---- Add new user to array and save ----
    users.push(newUser);   // Array.push() from Lab 4 - array.js (adds to end)
    saveUsers(users);      // saveUsers() from data.js

    // ---- Sign Up Success ----
    showAlert("signupAlert", "✅ Account created! You can now login.", "success");

    // After 1.5 seconds, switch to login tab so user can login
    setTimeout(function() {
        showTab("login");

        // Pre-fill the email in login form for convenience
        document.getElementById("loginEmail").value = email;
    }, 1500);

} // End of handleSignup()


/* -----------------------------------------------------------------------
   PAGE LOAD - If user is already logged in, redirect them away from login page
   Event concept from Events in JS lab (event.js line 110)
   ----------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function() {

    // If already logged in, don't show login page - redirect
    if (isLoggedIn()) {
        if (isAdmin()) {
            window.location.href = "admin.html";
        } else {
            window.location.href = "dashboard.html";
        }
    }

    console.log("✅ login.js loaded.");
});
