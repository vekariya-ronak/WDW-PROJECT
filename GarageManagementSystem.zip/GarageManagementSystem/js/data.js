/* =====================================================================
   FILE: data.js
   PURPOSE: Central data store for the entire application.
            All data is stored in localStorage so it persists between page reloads.
            This is the main DATA layer used by all other JS files.

   CONCEPTS USED FROM CLASS:
   - Arrays (Lab 4 - array.js)
   - Objects (Lab 4 - object.js)
   - Functions (Lab 3 - function.js)
   - Arrow Functions (Lab 3 - function.js)
   - JSON.parse / JSON.stringify for localStorage
   ===================================================================== */


/* -----------------------------------------------------------------------
   INITIAL DATA SETUP
   We use localStorage to store all app data permanently in the browser.
   localStorage is like a small database in the browser.
   ----------------------------------------------------------------------- */

// ---- Function: Initialize default data if app is running for first time ----
function initializeData() {

    // Check if users array already exists in localStorage
    // If not, create it with a default Admin user
    if (!localStorage.getItem("gms_users")) {

        // Default admin account (always pre-created)
        // Object concept from Lab 4 - object.js
        const defaultAdmin = {
            id: "admin_001",
            name: "Admin",
            email: "admin@garage.com",
            phone: "9999999999",
            password: "admin123",
            role: "admin"   // role can be "admin" or "user"
        };

        // Array concept from Lab 4 - array.js
        // We store the admin in an array of users
        const usersArray = [defaultAdmin];

        // Convert array to JSON string and save in localStorage
        localStorage.setItem("gms_users", JSON.stringify(usersArray));
    }

    // Check if cars array exists, if not create empty array
    if (!localStorage.getItem("gms_cars")) {
        // Sample car data to preload so marketplace is not empty
        // Array of Objects concept (Lab 4)
        const sampleCars = [
            {
                id: "car_001",
                ownerId: "admin_001",
                ownerName: "Ramesh Patel",
                contact: "9876543210",
                brand: "Toyota",
                model: "Fortuner",
                year: 2021,
                condition: "Excellent",
                km: 30000,
                price: 3500000,        // Price in INR (Indian Rupee)
                address: "Ahmedabad, Gujarat",
                description: "Well maintained Fortuner. Single owner. Full insurance.",
                photo: "",             // No photo for sample data
                isSold: false,         // false = still available for sale
                listedDate: "2026-09-01"
            },
            {
                id: "car_002",
                ownerId: "admin_001",
                ownerName: "Priya Shah",
                contact: "9123456780",
                brand: "Honda",
                model: "City",
                year: 2022,
                condition: "Good",
                km: 15000,
                price: 950000,
                address: "Surat, Gujarat",
                description: "Honda City in very good condition. All papers clear.",
                photo: "",
                isSold: false,
                listedDate: "2026-09-10"
            },
            {
                id: "car_003",
                ownerId: "admin_001",
                ownerName: "Suresh Kumar",
                contact: "9000012345",
                brand: "Maruti Suzuki",
                model: "Swift",
                year: 2020,
                condition: "Good",
                km: 45000,
                price: 620000,
                address: "Vadodara, Gujarat",
                description: "Swift petrol, excellent mileage, well maintained.",
                photo: "",
                isSold: true,          // This one is already sold (won't show in marketplace)
                listedDate: "2026-08-15"
            }
        ];

        localStorage.setItem("gms_cars", JSON.stringify(sampleCars));
    }

    // Check if services array exists, if not create empty array
    if (!localStorage.getItem("gms_services")) {
        localStorage.setItem("gms_services", JSON.stringify([]));
    }

    // Stats object: tracks total successful dealings and services
    // Object concept from Lab 4
    if (!localStorage.getItem("gms_stats")) {
        const defaultStats = {
            totalDeals: 1,      // 1 because car_003 is already sold in sample data
            totalServices: 0
        };
        localStorage.setItem("gms_stats", JSON.stringify(defaultStats));
    }

} // End of initializeData()


/* -----------------------------------------------------------------------
   GETTER FUNCTIONS
   These functions READ data from localStorage and return JS arrays/objects.
   Arrow function concept from Lab 3 - function.js
   ----------------------------------------------------------------------- */

// Get all users as an array
const getAllUsers = () => {
    return JSON.parse(localStorage.getItem("gms_users")) || [];
};

// Get all cars as an array
const getAllCars = () => {
    return JSON.parse(localStorage.getItem("gms_cars")) || [];
};

// Get only UNSOLD cars (for marketplace display)
const getAvailableCars = () => {
    const allCars = getAllCars();  // Get all cars first

    // Array filter() method to get only unsold cars
    // filter() loops through each car and keeps only those where isSold === false
    return allCars.filter(function(car) {
        return car.isSold === false;
    });
};

// Get all service requests
const getAllServices = () => {
    return JSON.parse(localStorage.getItem("gms_services")) || [];
};

// Get stats object
const getStats = () => {
    return JSON.parse(localStorage.getItem("gms_stats")) || { totalDeals: 0, totalServices: 0 };
};


/* -----------------------------------------------------------------------
   SETTER / SAVER FUNCTIONS
   These functions WRITE data back to localStorage.
   ----------------------------------------------------------------------- */

// Save updated users array to localStorage
const saveUsers = (usersArray) => {
    localStorage.setItem("gms_users", JSON.stringify(usersArray));
};

// Save updated cars array to localStorage
const saveCars = (carsArray) => {
    localStorage.setItem("gms_cars", JSON.stringify(carsArray));
};

// Save updated services array to localStorage
const saveServices = (servicesArray) => {
    localStorage.setItem("gms_services", JSON.stringify(servicesArray));
};

// Save updated stats to localStorage
const saveStats = (statsObj) => {
    localStorage.setItem("gms_stats", JSON.stringify(statsObj));
};


/* -----------------------------------------------------------------------
   UTILITY FUNCTIONS
   Small helper functions used across multiple files.
   Arrow function concept from Lab 3
   ----------------------------------------------------------------------- */

// Generate a unique ID using current timestamp (used when creating new records)
const generateId = (prefix) => {
    // Date.now() gives current time in milliseconds - always unique!
    return prefix + "_" + Date.now();
};

// Format price in Indian Rupee (INR) currency format
// Number.toLocaleString() converts number to string with commas
const formatINR = (amount) => {
    // 'en-IN' = English India locale, gives Indian number format (e.g., ₹3,50,000)
    return "₹" + Number(amount).toLocaleString("en-IN");
};


/* -----------------------------------------------------------------------
   INITIALIZE THE APP
   Call initializeData() when this script loads.
   This ensures the database is ready before any other script runs.
   ----------------------------------------------------------------------- */
initializeData();

// Confirm initialization in browser console (useful for debugging)
console.log("✅ data.js loaded. localStorage initialized.");
