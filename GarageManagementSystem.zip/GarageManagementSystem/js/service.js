/* =====================================================================
   FILE: service.js
   PURPOSE: Emergency Service Request page logic (service.html)
            - Check login before submitting service
            - Collect and validate service form
            - Save service request to localStorage
            - Show login required message if not logged in

   CONCEPTS USED FROM CLASS:
   - Objects (Lab 4 - object.js)
   - Array.push() (Lab 4 - array.js)
   - Functions (Lab 3 - function.js)
   - Conditional Statements (Lecture 3 - condt_stat.js)
   - DOM manipulation (firstdom.js)
   - Events (event.js)
   ===================================================================== */


/* -----------------------------------------------------------------------
   FUNCTION: submitServiceRequest
   PURPOSE : Validates service form and submits a new service request
   USES    : Object creation, Array.push(), Conditionals, DOM .value
   ----------------------------------------------------------------------- */
function submitServiceRequest() {

    // ---- Check if user is logged in first ----
    // isLoggedIn() from auth.js
    if (!isLoggedIn()) {
        // Show a warning message to login
        const loginAlert = document.getElementById("loginRequiredAlert");
        if (loginAlert) loginAlert.classList.remove("d-none");
        return;
    }

    // ---- Read form values (DOM .value property) ----
    const svcName     = document.getElementById("svcName").value.trim();
    const svcPhone    = document.getElementById("svcPhone").value.trim();
    const svcCarBrand = document.getElementById("svcCarBrand").value.trim();
    const svcCarModel = document.getElementById("svcCarModel").value.trim();
    const svcCarReg   = document.getElementById("svcCarReg").value.trim();
    const svcProblem  = document.getElementById("svcProblem").value.trim();
    const svcLocation = document.getElementById("svcLocation").value.trim();

    // Checkbox value: is alternate car needed?
    // .checked property for checkbox (Event handling from event.js)
    const needsAlternateCar = document.getElementById("alternateCar").checked;

    // ---- Form Validation (Conditional chain) ----
    if (svcName === "") {
        showServiceAlert("⚠️ Please enter your full name.", "warning"); return;
    }
    if (svcPhone === "" || svcPhone.length !== 10) {
        showServiceAlert("⚠️ Please enter a valid 10-digit phone number.", "warning"); return;
    }
    if (svcCarBrand === "") {
        showServiceAlert("⚠️ Please enter your car brand.", "warning"); return;
    }
    if (svcCarModel === "") {
        showServiceAlert("⚠️ Please enter your car model.", "warning"); return;
    }
    if (svcCarReg === "") {
        showServiceAlert("⚠️ Please enter your car registration number.", "warning"); return;
    }
    if (svcProblem === "") {
        showServiceAlert("⚠️ Please describe the problem with your car.", "warning"); return;
    }
    if (svcLocation === "") {
        showServiceAlert("⚠️ Please enter your current location.", "warning"); return;
    }

    // ---- Get Current User ----
    const user = getCurrentUser();  // auth.js

    // ---- Create Service Request Object (Object concept - Lab 4) ----
    const newService = {
        id:                generateId("svc"),       // Unique ID from data.js
        userId:            user.id,                  // Link to the user
        userName:          user.name,                // User's name
        userEmail:         user.email,               // User's email
        name:              svcName,                  // Contact name for mechanic
        phone:             svcPhone,                 // Contact phone
        carBrand:          svcCarBrand,
        carModel:          svcCarModel,
        carReg:            svcCarReg,
        problem:           svcProblem,
        location:          svcLocation,
        needsAlternateCar: needsAlternateCar,
        status:            "Pending - Mechanic Assigned",  // Initial status
        date:              new Date().toLocaleDateString("en-IN")  // Today's date
    };

    // ---- Add service to array and save ----
    const allServices = getAllServices();  // data.js
    allServices.push(newService);          // Array.push() from Lab 4
    saveServices(allServices);             // Save to localStorage

    // ---- Update Stats ----
    // (Stats will be updated when service is "Completed" - done by admin)

    // ---- Show Success Message ----
    showServiceAlert(
        "✅ Service request submitted! A mechanic will reach your location shortly. Track status in your dashboard.",
        "success"
    );

    // ---- Reset the form ----
    resetServiceForm();

    console.log("✅ New service request created:", newService);

} // End of submitServiceRequest()


/* -----------------------------------------------------------------------
   FUNCTION: showServiceAlert
   PURPOSE : Shows alert message on service page
   PARAMS  : message - text to display
             type    - Bootstrap alert type ("success", "danger", "warning")
   ----------------------------------------------------------------------- */
function showServiceAlert(message, type) {
    const alertEl = document.getElementById("serviceAlert");
    if (alertEl) {
        alertEl.className = "alert alert-" + type;
        alertEl.textContent = message;
    }
}


/* -----------------------------------------------------------------------
   FUNCTION: resetServiceForm
   PURPOSE : Clears all input fields after form submission
   USES    : for...of loop, DOM .value = ""
   ----------------------------------------------------------------------- */
function resetServiceForm() {

    // Array of field IDs to reset
    const fields = ["svcName", "svcPhone", "svcCarBrand", "svcCarModel", "svcCarReg", "svcProblem", "svcLocation"];

    // for...of loop from Lab 2 to reset each field
    for (let fieldId of fields) {
        const el = document.getElementById(fieldId);
        if (el) el.value = "";
    }

    // Reset checkbox to checked (default state)
    const checkbox = document.getElementById("alternateCar");
    if (checkbox) checkbox.checked = true;

} // End of resetServiceForm()


/* -----------------------------------------------------------------------
   PAGE LOAD - Initialize service page when DOM is ready
   Pre-fill user's name and phone if logged in (for convenience)
   DOMContentLoaded event (event.js line 110)
   ----------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function() {

    const user = getCurrentUser();

    // If user is logged in, pre-fill their name and phone
    if (user) {
        const svcName  = document.getElementById("svcName");
        const svcPhone = document.getElementById("svcPhone");

        // Pre-fill known info so user doesn't have to type it again
        if (svcName)  svcName.value  = user.name;
        if (svcPhone) svcPhone.value = user.phone;
    } else {
        // Show login required alert if not logged in
        const loginAlert = document.getElementById("loginRequiredAlert");
        if (loginAlert) loginAlert.classList.remove("d-none");
    }

    console.log("✅ service.js loaded.");
});
